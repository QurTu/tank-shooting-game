
import AllGame from './AllGame.js';


new AllGame();


 